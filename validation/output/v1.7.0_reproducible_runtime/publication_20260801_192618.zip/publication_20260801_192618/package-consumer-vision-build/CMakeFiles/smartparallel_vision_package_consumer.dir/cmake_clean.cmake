file(REMOVE_RECURSE
  "CMakeFiles/smartparallel_vision_package_consumer.dir/main.cpp.obj"
  "CMakeFiles/smartparallel_vision_package_consumer.dir/main.cpp.obj.d"
  "smartparallel_vision_package_consumer.exe"
  "smartparallel_vision_package_consumer.exe.manifest"
  "smartparallel_vision_package_consumer.lib"
  "smartparallel_vision_package_consumer.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/smartparallel_vision_package_consumer.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
