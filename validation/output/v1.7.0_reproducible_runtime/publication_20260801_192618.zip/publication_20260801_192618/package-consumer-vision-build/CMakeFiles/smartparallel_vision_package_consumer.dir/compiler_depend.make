﻿# Empty compiler generated dependencies file for smartparallel_vision_package_consumer.
# This may be replaced when dependencies are built.
