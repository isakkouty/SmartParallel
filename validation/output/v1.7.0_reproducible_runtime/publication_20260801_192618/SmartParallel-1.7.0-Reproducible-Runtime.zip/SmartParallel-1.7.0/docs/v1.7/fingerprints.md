# v1.7 Runtime and operation fingerprints

The Runtime fingerprint includes SmartParallel version, execution mode, profile access, configured and effective worker budgets, numerical default, scheduler capability identity, hardware identity, compiler/standard-library build identity, floating-point environment, and application build identifier.

Operation fingerprints add semantic operation and workload identity, numerical algorithm and canonical plan, profile database and entry hashes, trust state, selected route and scheduler, worker counts, SIMD/provider identity, forced-route state, warm-start state, and deterministic-replay state.

Addresses, process IDs, timestamps, thread IDs, output paths, and durations are excluded from stable hashes.
