# v1.7 ExecutionContext API

```cpp
smart::RuntimeOptions options;
options.worker_budget = 8;
smart::Runtime runtime(options);
auto context = runtime.context();

smart::parallel_for(context, 0u, count, callback);
smart::linalg::axpy(context, y, alpha, x, numerical_options);
```

The context is cheap to copy and carries Runtime ownership, configuration identity, nested-execution lineage, and the exact-plan override used by deterministic replay. Copying does not duplicate a pool or profile database.

Context-aware overloads are provided for `parallel_for`, generic Fast `parallel_reduce`, AXPY, dot, norm, stencil 2D, and Vision threshold. Arbitrary callbacks do not receive persistent cross-process identities.
