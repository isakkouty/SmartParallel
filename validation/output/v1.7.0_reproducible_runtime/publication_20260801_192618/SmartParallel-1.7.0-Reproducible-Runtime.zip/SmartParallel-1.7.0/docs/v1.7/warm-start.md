# v1.7 Adaptive warm start

Only profiles loaded from storage count as restart warm-start evidence. Newly learned entries in the same Runtime do not masquerade as a process restart.

A compatible loaded entry is authenticated and used for the first Adaptive semantic-operation call. Later calls return to normal current-context adaptation, allowing stale routes to be replaced. ReadOnly files remain byte-identical; updated Candidate evidence is exported only through an explicit ReadWrite save.
