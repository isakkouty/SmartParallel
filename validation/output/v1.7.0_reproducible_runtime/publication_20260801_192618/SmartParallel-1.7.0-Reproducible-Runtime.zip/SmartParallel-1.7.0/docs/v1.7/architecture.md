# v1.7 Reproducible Runtime architecture

A `smart::Runtime` owns an immutable configuration snapshot, scheduler and provider capability identity, floating-point-environment identity, a synchronized in-memory profile database, adaptive evidence, telemetry, and fingerprint state. `Runtime::context()` returns a small shared-state handle. Context-aware free-function overloads preserve the project’s established API style.

Adaptive and Deterministic dispatch are separate paths. Adaptive execution may use a compatible profile once as a warm start and then return to normal current-context behavior. Deterministic execution requires an exact Approved semantic profile, or a deliberately forced scheduler when profile access is Disabled. The exact-plan branch bypasses profiling, exploration, holdout, drift detection, route switching, and profile mutation.

Profiles are loaded only during Runtime construction or an explicit `load_profiles` call. Operations never perform profile-file I/O. Saving is explicit and atomic.
