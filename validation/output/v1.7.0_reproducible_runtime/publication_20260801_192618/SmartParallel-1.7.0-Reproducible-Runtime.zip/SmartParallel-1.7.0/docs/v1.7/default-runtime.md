# v1.7 backward-compatible default Runtime

Existing free-function calls remain source compatible. A process-default Runtime supplies ownership and diagnostic state, while the legacy mutable global configuration remains effective for those calls. Explicit Runtime instances always use their own construction-time snapshot.

The legacy path is convenient for existing applications. New integrations should construct a Runtime and pass its context explicitly, especially when isolation, persistent profiles, or deterministic replay is required.
