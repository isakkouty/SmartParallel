# SmartParallel v1.7.0 — Reproducible Runtime release notes

**Trust statement:** **v1.7 — Trust the experiment.**

v1.7 introduces owned Runtime configuration, lightweight contexts, default-Runtime compatibility, persistent exact semantic profiles, Candidate/Approved approval, canonical bounded JSON, SHA-256 integrity, atomic explicit saving, Adaptive warm starts, no-maintenance Deterministic replay, Runtime and operation fingerprints, calibration/profile/replay tools, stable experiment manifests, and a separate-process heat-diffusion proof.

Existing v1.0–v1.6 schedulers, numerical kernels, Vision routes, scientific operations, and free-function APIs remain in place. Optional public execution-lineage scopes were deferred.
Publication timing validation uses fresh repetition-matched Runtime instances and deterministic bootstrap 95% intervals. Noisy intervals that cross an objective are reported as `INCONCLUSIVE-PASS`; only statistically credible misses fail the release workflow.
