# v1.7 profile inspection and comparison

`smartparallel_profile inspect` prints entries, status, numerical policy, route, scheduler, worker budget, sample count, workload fingerprint, and entry hash. `validate` checks canonical parsing and integrity. `compare` reports database-hash equality and meaningful per-entry differences. `approve` is the only supplied transition from Candidate to Approved.
