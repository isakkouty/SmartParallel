# v1.7 profile schema

The experimental profile format uses canonical JSON:

- schema major `1`;
- semantic version `1.0`;
- SmartParallel and environment identity;
- exact semantic-operation and workload identity;
- execution route, scheduler, worker plan, numerical contract, and provider identity;
- evidence and Candidate/Approved status;
- per-entry and database SHA-256 integrity hashes.

Supported persistent semantic operations are `smart.vision.threshold`, `smart.linalg.axpy`, `smart.linalg.dot`, `smart.linalg.norm`, and `smart.scientific.stencil_2d`. Arbitrary lambdas are not persisted. Unknown major schemas are rejected; automatic schema migration is not promised.
