# v1.7 experiment run manifests

The heat-diffusion replay tool writes a stable schema-v1 JSON manifest containing application identity, dimensions, iteration count, boundary mode, numerical policy, seed, input and output digests, Runtime fingerprint, profile database hash, operation fingerprints, worker budget, final norm identity, and completion status.

The separate `.sha256` file identifies the manifest bytes. Diagnostics that vary by process are not included in the stable identity.
