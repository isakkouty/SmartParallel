# SmartParallel v1.7 — Reproducible Runtime

**v1.7 — Trust the experiment.**

SmartParallel v1.7 adds an owned `Runtime`, lightweight `ExecutionContext`, persistent semantic-operation profiles, explicit Candidate/Approved trust states, deterministic exact replay, stable execution fingerprints, and a cross-process heat-diffusion proof. The v1.0–v1.6 free-function APIs remain available through the process-default Runtime compatibility path.

## Start here

- [Architecture](architecture.md)
- [Runtime ownership and lifetime](runtime-ownership.md)
- [ExecutionContext API](execution-context.md)
- [Adaptive versus Deterministic execution](execution-modes.md)
- [Profile schema and trust states](profile-schema.md)
- [Calibration, approval, and replay](calibration.md)
- [Cross-process heat-diffusion pilot](cross-process-heat-diffusion.md)
- [Benchmark reproduction](benchmark-reproduction.md)
- [Security and trust boundaries](security-and-trust.md)
- [Known limitations](limitations.md)
- [Migration from v1.6](migration.md)
- [Release notes](release-notes.md)
