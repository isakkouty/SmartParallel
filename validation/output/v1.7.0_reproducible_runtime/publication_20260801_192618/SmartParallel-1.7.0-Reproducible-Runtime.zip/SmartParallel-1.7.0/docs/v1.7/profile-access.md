# v1.7 profile access policies

`Disabled` performs no profile-file loading or saving. Adaptive execution uses the existing in-process runtime learning. Deterministic generic callbacks require an explicit forced scheduler.

`ReadOnly` loads a profile database and never writes it. Adaptive execution may use compatible entries as warm-start evidence. Deterministic execution may replay exact Approved entries.

`ReadWrite` permits explicit export through `Runtime::save_profiles` and the calibration tools. There is no destructor save, periodic save, or operation-time file access. Concurrent multi-process writers are unsupported.
