# v1.7 exact workload identity

The workload fingerprint hashes the stable operation name and version, element type, numerical policy, logical extents, element or byte strides, layout, boundary mode, in-place state, and operation constants such as AXPY alpha, threshold values, and stencil coefficients.

Deterministic lookup is exact. No nearest-neighbor or fuzzy workload matching is performed. A changed extent, stride, policy, boundary condition, or semantic constant rejects the profile before execution.
