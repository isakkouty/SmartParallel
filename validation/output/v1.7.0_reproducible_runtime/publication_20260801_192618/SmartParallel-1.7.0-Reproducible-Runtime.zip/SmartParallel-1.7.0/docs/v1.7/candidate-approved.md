# v1.7 Candidate and Approved profiles

Adaptive calibration and explicit export create Candidate entries. Candidates may warm-start Adaptive execution but are rejected by Deterministic mode.

`smartparallel_profile approve` validates integrity, sample count, confidence, holdout, route authentication, numerical capability, and correctness evidence. It then writes a new Approved profile with a new hash and preserves the Candidate source hash. Calibration never approves silently.
