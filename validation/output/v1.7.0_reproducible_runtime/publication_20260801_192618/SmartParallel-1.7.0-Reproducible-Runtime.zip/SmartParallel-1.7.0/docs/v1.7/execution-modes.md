# v1.7 Adaptive versus Deterministic execution

Adaptive execution may learn, use in-memory evidence, warm-start from compatible Candidate or Approved profiles, and replace stale decisions. A loaded profile is a starting point, not a permanent freeze. Profile files are never automatically rewritten.

Deterministic execution accepts only an exact Approved semantic-operation profile. It uses the saved route, scheduler, worker budget, and numerical plan. Missing, Candidate, corrupted, expired, unavailable, or incompatible profiles fail before destination data is modified. There is no silent scheduler substitution or fallback to Adaptive mode.

Telemetry exposes counters for learning samples, timing probes, holdout probes, drift probes, route switches, and profile mutations. These remain zero during deterministic replay.
