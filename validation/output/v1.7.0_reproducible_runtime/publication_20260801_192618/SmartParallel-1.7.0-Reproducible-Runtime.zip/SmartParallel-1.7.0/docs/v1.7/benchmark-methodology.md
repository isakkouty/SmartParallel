# v1.7 benchmark methodology

The v1.7 benchmark compares the unchanged free-function API, explicit Runtime calls, and copied ExecutionContext calls on the same AXPY workload. It also measures Adaptive cold execution, profile-loaded Adaptive warm start, Deterministic replay, Runtime construction, and profile parsing at 1, 10, 100, and 1,000 entries.

## Paired startup evidence

Every startup repetition creates three fresh Runtime instances:

- Adaptive with ReadWrite access and no loaded profile, which must create new Candidate evidence;
- Adaptive with a compatible loaded Candidate profile, which must authenticate and warm-start;
- Deterministic with a compatible loaded Approved profile, which must replay without adaptive maintenance.

The three variants use identical inputs and are compared only after the benchmark verifies identical output. Their execution order rotates by repetition to avoid a fixed first/last bias. A separate unmeasured operation warms the shared backend before collection; it does not warm any measured Runtime.

The calibration Runtime that produces the Candidate profile is not reused as a source of “cold” timing. Repeatedly timing one calibration Runtime would mix cold operation dispatch with increasingly warm process-local state and is not portable evidence.

## Statistical acceptance

The analyzer uses repetition-matched pairs and deterministic bootstrap 95% intervals:

- median paired overhead for Runtime and copied-context calls;
- median paired cold/warm speedup;
- median paired Deterministic/warm latency ratio;
- bootstrap median profile-load time.

A complete interval satisfying an objective is `PASS`. A complete interval violating an objective is `FAIL`. An interval crossing the objective is `INCONCLUSIVE-PASS`, because the release contract explicitly forbids failing noisy measurements without statistically credible evidence.

The profile-scale guard requires a 1,000-entry exact profile database to load in less than one second at the upper confidence bound. This is a construction-time bound of at most approximately 1 ms per entry; profile files are never accessed on operation hot paths.

Results are local-machine evidence, not universal speed claims. The v1.5 and v1.6 publication suites remain separate regression guards for existing routes and scientific kernels.
