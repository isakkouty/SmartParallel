# v1.7 offline calibration, approval, and inspection

Build with `-DSMARTPARALLEL_BUILD_V170_TOOLS=ON`.

```sh
smartparallel_calibrate calibration.json
smartparallel_profile inspect evidence/candidate_profile.json
smartparallel_profile approve evidence/candidate_profile.json evidence/approved_profile.json
smartparallel_profile validate evidence/approved_profile.json
```

The calibration manifest is schema version 1 and identifies the operation, exact dimensions, numerical policy, worker budget, repetitions, deterministic seed, and output directory. The tool emits a Candidate profile, raw and summary CSV, metrics and environment JSON, compatibility report, operation fingerprints, SHA-256 file, and Markdown report.
