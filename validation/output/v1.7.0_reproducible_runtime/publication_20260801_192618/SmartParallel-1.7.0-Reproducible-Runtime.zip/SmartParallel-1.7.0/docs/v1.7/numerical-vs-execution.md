# v1.7 numerical policy versus execution mode

Execution mode controls whether the runtime may learn or change plans. Numerical policy controls evaluation order and floating-point behavior.

- Deterministic + Fast replays the same approved execution plan, but Fast may still permit floating-point variation.
- Deterministic + Reproducible replays the exact plan and the v1.6 canonical numerical decomposition.
- Deterministic + Accurate replays the exact plan and the v1.6 accurate numerical algorithm.

Reports and fingerprints record both dimensions independently.
