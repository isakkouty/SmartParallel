# v1.7 cross-process heat-diffusion pilot

The pilot reuses the v1.6 five-point stencil and norm operations.

1. `smartparallel_calibrate` generates deterministic input, runs Adaptive calibration, validates outputs, and writes Candidate stencil and norm profiles.
2. `smartparallel_profile approve` creates a distinct Approved profile.
3. Two fresh `smartparallel_replay run` processes load the profile ReadOnly in Deterministic mode.
4. `smartparallel_replay compare` requires byte-identical stable manifests.

The validation also hashes the Approved file before and after replay and requires it to remain unchanged. Reproducible output fields and operation fingerprints must match.
