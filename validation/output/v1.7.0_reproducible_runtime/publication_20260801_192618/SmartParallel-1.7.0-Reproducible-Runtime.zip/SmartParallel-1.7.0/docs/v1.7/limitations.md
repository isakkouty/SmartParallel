# v1.7 known limitations

- No process-wide governor coordinates independent Runtime instances.
- No cross-architecture, cross-compiler, or cross-provider bitwise guarantee.
- Concurrent multi-process profile writers are unsupported.
- Profiles are exact workload identities, not portable optimization guarantees.
- Arbitrary callback persistence, fuzzy deterministic matching, automatic schema migration, cryptographic signing, remote profile services, OpenMP, BLAS, FFT, NUMA, affinity, cancellation, deadlines, GPU, MPI, C, and Python APIs are excluded.
- Public named execution scopes and execution-tree export remain deferred optional work.
- Scientific and profile APIs remain experimental and do not promise stable ABI.
