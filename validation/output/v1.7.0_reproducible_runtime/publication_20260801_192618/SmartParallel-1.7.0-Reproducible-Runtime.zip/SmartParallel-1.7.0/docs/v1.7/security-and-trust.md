# v1.7 security and trust boundaries

Profiles are bounded and strictly parsed, duplicate keys are rejected, numeric overflow and excessive depth/size are rejected, and SHA-256 detects accidental or untrusted modification. These controls are not digital signatures, sandboxing, safety certification, or authorization.

Deterministic mode reproduces an approved execution identity only under compatible hardware, build, provider, and floating-point conditions. Fast numerical policy does not become bitwise reproducible merely because route selection is deterministic.
