# v1.7 accepted benchmark evidence

The accepted Linux/GCC publication retained under [`assets/benchmarks/`](assets/benchmarks/README.md) uses 31 repetitions for the v1.7 Runtime/profile suite and 11 repetitions for the v1.6 scientific regression suite. Measurements are machine-specific and are not universal speed guarantees.

## v1.7 objective results

The corrected publication methodology uses fresh paired Runtime instances and deterministic bootstrap 95% intervals. On the accepted Linux/GCC run:

- Adaptive warm start was **2.29× faster** than fresh cold Adaptive execution, with a **2.15–2.46×** 95% interval.
- Deterministic replay was **0.963×** the warm Adaptive latency, with a **0.940–1.087×** interval.
- Explicit Runtime paired overhead was **-10.927 µs** and copied-context paired overhead was **16.124 µs**. Their intervals crossed the 20 µs objective, so both are reported as **INCONCLUSIVE-PASS**, not as regressions.
- A 1,000-entry profile validated and loaded in **154.696 ms**, with a **153.897–155.395 ms** interval.
- No benchmark objective had a statistically credible failure.

## Cross-process proof

The accepted pilot calibrated a padded 64×64 heat workload with row stride 68, explicitly approved the resulting stencil and norm profiles, and launched two fresh Deterministic ReadOnly processes. The manifests were byte-identical with SHA-256 `bf38a80094c377617a2c4e5a8710fc5ae954322289cb4d3e0bf3019999142e76`; the output digest was `d1ed054ac93a51dcf69535150d5a59a864aa8bd0eca8ef6cf14814469afd4975`. Both manifests contain two stable semantic-operation fingerprints and nine deterministic replays. Learning, timing, holdout, drift, route-switch, warm-start, cold-start, and profile-mutation counters are zero.

## v1.6 regression guard

All v1.6 correctness, numerical-capability, reproducibility, and route-authentication gates passed. The largest Fast cases measured **1.242× AXPY**, **2.692× dot**, **2.848× norm**, **3.607× stencil**, and **1.811× 20-step heat diffusion** versus compact direct-sequential references on this machine. The paired Fast compatibility ratio was **0.9067× [0.8188, 1.0041]** and passed the retained analysis rule.

## Reproduction

Run the release-validation script to regenerate raw evidence, metrics, reports, plots, install-tree tests, the CLI pilot, and an exact-ZIP rebuild for the current machine. See the [benchmark methodology](benchmark-methodology.md) and [reproduction guide](reproduction-guide.md).
