# v1.7 compatibility rules

Deterministic compatibility validates operation and semantic version, type, policy, evaluation order, accumulation algorithm, canonical plan, exact workload identity, architecture, pointer width, endianness, OS, compiler/build fingerprint, floating-point environment, application build identifier, worker budget, scheduler availability, provider identity, approval state, evidence gates, and expiry.

Adaptive mode ignores incompatible entries as authoritative evidence and continues through the existing learner. Incompatible evidence does not mutate the selected plan.
