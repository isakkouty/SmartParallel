# v1.7 benchmark reproduction

Linux/macOS:

```sh
sh scripts/validation/run_v17_reproducible_runtime_release_validation.sh 11 smoke
```

Windows from a Developer Command Prompt:

```bat
scripts\validation\run_v17_reproducible_runtime_release_validation.bat 11 smoke
```

The benchmark executable can also be launched directly:

```sh
build/v17_release/benchmarks/v1.7.0/smartparallel_v170_reproducible_runtime_benchmarks validation/output/v1.7-local 11
python3 tools/analyze_v17_reproducible_runtime.py validation/output/v1.7-local/raw.csv validation/output/v1.7-local/analysis
```
