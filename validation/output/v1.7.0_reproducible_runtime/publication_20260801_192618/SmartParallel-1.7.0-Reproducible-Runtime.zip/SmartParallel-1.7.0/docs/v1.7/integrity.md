# v1.7 profile integrity and limitations

SHA-256 is calculated over canonical JSON excluding the hash field itself. Entry hashes and the database hash detect changed bytes, truncation, malformed content, and semantic modification. Equivalent accepted JSON is reserialized canonically.

SHA-256 detects integrity changes. It does not prove authorship, organizational approval, or resistance to a malicious party capable of replacing both content and hash. Cryptographic signatures are outside v1.7.
