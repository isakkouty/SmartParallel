# v1.7 release reproduction guide

Configure a clean Release build with validation, tools, benchmarks, examples, and installation enabled. Run CTest, the cross-process pilot, documentation validation, install-tree consumers, the v1.6 scientific benchmark regression, and the v1.7 benchmark. Repeat in no-oneTBB, sanitizer, and Clang warnings-as-errors configurations where available.

Finally create the source-only ZIP with `tools/create_source_release_zip.py`, extract that exact ZIP into a new directory, repeat the focused build/tests/pilot, and record the archive SHA-256.
