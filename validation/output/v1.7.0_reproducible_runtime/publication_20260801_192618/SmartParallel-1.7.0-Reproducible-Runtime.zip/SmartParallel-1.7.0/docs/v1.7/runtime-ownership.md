# v1.7 Runtime ownership and lifetime

`RuntimeOptions` are validated and snapshotted during construction. Subsequent changes to `smart::global_config()` do not mutate an explicit Runtime. Adaptive evidence remains internally mutable, synchronized, and Runtime-owned.

An `ExecutionContext` keeps the Runtime state alive with a shared handle, so a copied context remains usable after the original `Runtime` wrapper is destroyed. One Runtime supports concurrent calls. Separate Runtime instances do not share profile databases or configuration snapshots.

Multiple Runtime instances may collectively oversubscribe the machine because v1.7 has no process-wide resource governor. That limitation is explicit and belongs to a later release.
