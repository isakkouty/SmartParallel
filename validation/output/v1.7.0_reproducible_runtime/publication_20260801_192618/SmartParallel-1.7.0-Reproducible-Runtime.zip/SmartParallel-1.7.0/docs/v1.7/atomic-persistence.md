# v1.7 atomic persistence

Saving serializes canonical content, writes a temporary file in the destination directory, flushes and closes it, reopens and validates it, verifies integrity, and atomically replaces the destination. POSIX uses same-directory rename; Windows uses `MoveFileEx` with replacement and write-through flags.

A failed temporary write or validation leaves the prior destination intact. Temporary files are removed by scoped cleanup. Multi-process writers remain unsupported.
