# v1.7 optional execution lineage

The mandatory v1.7 release retains the existing bounded nested-execution trace and operation fingerprint reporting. The proposed public named `ExecutionScope` API and JSON execution-tree export were not added because they are optional and were intentionally deferred until the mandatory Runtime, persistence, deterministic replay, tooling, and regression gates were stable.
