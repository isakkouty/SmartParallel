# v1.7 migration from v1.6

No source change is required for existing v1.6 code. Free functions remain available. To adopt isolation, create `RuntimeOptions`, construct a `Runtime`, obtain a context, and pass it as the first argument to supported operations.

To adopt restart persistence, calibrate into a ReadWrite Candidate file, inspect it, approve it explicitly, then construct a Deterministic ReadOnly Runtime using the exact same worker budget, build identifier, numerical policy, workload shape, and provider environment.
